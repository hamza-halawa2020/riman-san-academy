# SemanticUI Admin Template AngularJs

Free SemanticUI admin dashboard template with angularjs boilerplate is great to start any type of web application like user dashboard, admin dashboard, services dashboard.

If anyone wants to start their project with angularjs and good responsive framework other than bootstrap, then this is right choice. SemanticUI has lot of good component where developers needs to focus only on their bussiness logic rather than spending time on design. 

# Preview
<img src="http://hostmasterzone.com/SemanticUI-Admin-Template-AngularJs/SemanticUI-Admin-Template-AngularJs-800x0b1024x768.jpg"></img>

# Credits
<ul>
 <li><a href="https://angularjs.org">angularjs</a></li>
 <li><a href="https://semantic-ui.com">semantic-ui</a></li>
 <li><a href="https://jquery.com">jQuery</a></li>
 <li><a href="http://www.chartjs.org">chartjs</a></li>
 <li><a href="http://momentjs.com">momentjs</a></li>
 <li><a href="http://hostmasterzone.com">Hostmasterzone</a></li>
 </ul>
